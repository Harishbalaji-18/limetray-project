package com.limetraysignup1.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.limetraysignup1.DAO.SignupDAO;
import com.limetraysignup1.model.Admin;


@Service
public class Signupservice {
	@Autowired
	SignupDAO dao;

	public ArrayList<Admin> display() {
		return dao.displayUser();
	}

	

}
	